for i in range(17):
    print("{0:>2} in binary is {0:>08b}".format(i))
    