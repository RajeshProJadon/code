# list_1 = []
# list_2 = list()
#
# print("list 1 {}".format(list_1))
# print("list 2 {}".format(list_2))
#
# if list_1 == list_2:
#     print("The lists are equal")
#
# print(list("The list are equal"))

even = [2, 4, 6, 8]

another_even = even
another_even.sort(reverse=True)
print(even)
