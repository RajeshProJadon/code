# -*- coding: utf-8 -*-
"""
Created on Sun Dec 17 03:44:35 2017

@author: abc
"""

greeting = "Hello"
name = input("Please enter your name")
print(greeting + ' ' +name)