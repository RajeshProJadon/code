from blackjack import *

g = sorted(globals())

for x in g:
    print(x)
# print(__name__)
# blackjack.play()
