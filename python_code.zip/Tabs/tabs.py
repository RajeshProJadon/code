for i in range(1, 12):
    print("No {} squared is {} and cubed {:4}".format(i, i ** 2, i ** 3))
    print("Calculation complete")
    print("Try Again")
               