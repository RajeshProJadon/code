# import turtle
#
#
# turtle.forward(150)
# turtle.right(250)
# turtle.forward(150)
#
# turtle.done()

# from turtle import forward, right, done, circle
from turtle import *


forward(150)
right(200)
circle(70)
forward(150)

done()