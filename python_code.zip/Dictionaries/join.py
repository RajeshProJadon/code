myList = ["a", "b", "c", "d"]
letters = "abcdefghijklmnopqrstuvwxyz"

newString = ''
for c in myList:
    newString = ",".join(letters)
    # print(newString)

print(newString)

