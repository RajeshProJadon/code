bike = {"make": "motor", "model": "250 dream", "color": "red", "engine_size": 250}
print(bike["engine_size"])
print(bike["color"])
