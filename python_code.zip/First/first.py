print("Hi Rajesh !")

